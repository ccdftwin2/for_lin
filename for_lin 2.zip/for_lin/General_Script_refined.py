import numpy as np 
import pandas as pd 
from helper import *
import sys

def main():
    print(sys.argv)
    tissue_name = sys.argv[2]
    tissue_name, file_name = file_names(tissue_name=tissue_name)
    num_perm = 200000
    for (time, strain) in [(sys.argv[3], sys.argv[4])]:
        data = good_columns(file_name, tissue_name, time=time, strain=strain)

        p_values = pd.read_csv("{}_{}_{}.csv".format(tissue_name, time, strain), header=0)
        
        # selected gene ids
        p_values = p_values[p_values['p'] < 0.012]['a_gene_id']
        
        # filter the data frame
        data = data[data['a_gene_id'].isin(p_values)]
        
        final_gene_ids = []
        for i in range(len(data)):
            temp_row = data.iloc[i].to_numpy()
            a_substance_id = temp_row[0]
            gene_id = temp_row[1]
            data_lean = temp_row[2:7]
            data_obese = temp_row[7:]
            
            # run the permutation test
            p, num_perm = permutation(data_lean=data_lean, data_obese=data_obese, num_perm=num_perm)
            if p < 0.004:
                p2, num_perm_2 = permutation(data_lean=data_lean, data_obese=data_obese, num_perm=200000)
    
                if (p*num_perm + p2*num_perm_2)/(num_perm + num_perm_2) < 0.001:
                    p3, num_perm_3 = permutation(data_lean=data_lean, data_obese=data_obese, num_perm=200000)
                    if (p*num_perm + p2*num_perm_2 + p3*num_perm_3)/(num_perm_3 + num_perm + num_perm_2) < 0.00005:
                        p4, num_perm_4 = permutation(data_lean=data_lean, data_obese=data_obese, num_perm=250000)
                        final_gene_ids.append([a_substance_id, gene_id, num_perm, (p*num_perm + p2*num_perm_2 + p3*num_perm_3 + p4*num_perm_4)/(num_perm_4 + num_perm_3 + num_perm + num_perm_2)])
                    else:
                        final_gene_ids.append([a_substance_id, gene_id, num_perm, (p*num_perm + p2*num_perm_2 + p3*num_perm_3)/(num_perm_3 + num_perm + num_perm_2)])
                else:
                    final_gene_ids.append([a_substance_id, gene_id, num_perm, (p*num_perm + p2*num_perm_2)/(num_perm + num_perm_2)])
            else:
                final_gene_ids.append([a_substance_id, gene_id, num_perm, p])
            
        # lets write to files
        save_file_name = "{}_{}_{}_adapted_3.csv".format(tissue_name, time, strain)
        pd.DataFrame(np.array(final_gene_ids), columns=["a_substance_id", "a_gene_id", "num_perm", "p"]).sort_values("p").to_csv(save_file_name, index=False)

if __name__ == '__main__':
    main()
